package com.php.Customer;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassCustomer;

public class CustomerDashboard extends BaseClassCustomer {
	WebDriver driver;
	
	@FindBy(xpath="//a[text()=' My Bookings' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement mybookings; 
	
	
	@FindBy(xpath="//a[text()=' View Voucher']")
	private WebElement view; 
	
	
	@FindBy(xpath="//a[text()=' Add Funds' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement addfunds; 
	
	@FindBy(xpath="//input[@id='gateway_paypal']")
	private WebElement selectpaypal; 
	
	@FindBy(xpath="//button[text()='Pay Now ']")
	private WebElement paynow; 
	
	@FindBy(xpath="//div[@class='btn-front' and @style='display:flex']")
	private WebElement back; 
	
	@FindBy(xpath="//a[text()='Yes']")
	private WebElement yesbutton; 
	
	@FindBy(xpath="//a[text()=' My Profile' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement myprofile; 
	
	@FindBy(xpath="//h3[text()='Address']")
	private WebElement address;
	
	
	@FindBy(xpath="//input[@name='address1']")
	private WebElement changeaddress;
	
	@FindBy(xpath="//button[text()='Update Profile']")
	private WebElement update;
	
	
	@FindBy(xpath="//div[@class='alert alert-success']")
	private WebElement notification;
	
	@FindBy(xpath="//a[text()=' Logout' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement logout;
	
	
	 public CustomerDashboard(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
			}
	 
	 public void clickMyBookings() throws InterruptedException
	 {
		
		 mybookings.click();
		
	 }
	 
	 public void clickViewVoucher() throws InterruptedException
	 {
		
		 view.click();
		 Thread.sleep(6000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		 Thread.sleep(2000);
	 }
	 public void clickAddFunds() throws InterruptedException
	 {
		
		 addfunds.click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		
	 }
	 
	 public void selectPayPal() throws InterruptedException
	 {
		
		 selectpaypal .click();
		 Thread.sleep(2000);
		 paynow.click();
		 Thread.sleep(6000);
		  back.click();
		 Thread.sleep(2000);
		 yesbutton.click();
		 Thread.sleep(3000);
		  }
	 public void clickMyProfile() throws InterruptedException
	 {
		
		myprofile.click();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,750)", "");
		 Thread.sleep(2000);
		 js.executeScript("arguments[0].style.border='2px solid red'",address);
		 Thread.sleep(2000);
		
		  }
	 
	 public void UpdateAddress(Object Address) throws InterruptedException
		{
			changeaddress.clear();
			Thread.sleep(3000);
			changeaddress.sendKeys(Address.toString() );
			Thread.sleep(7000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,650)", "");
			 Thread.sleep(2000);
			update.click();
			Thread.sleep(2000);
			
		}
	 public void GetNotification()
	 {
	String value=notification.getText();
	System.out.println("Notification after updating the profile:" +value);
	 }
	 public void Logout()
	 {
		 logout.click();
	 }
	 
}


