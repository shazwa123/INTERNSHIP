package com.php.Admin;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.php.Base.BaseClassAdmin;

public class AdminDashboard extends BaseClassAdmin {
	
	WebDriver driver;

	@FindBy(linkText="Bookings")
	//@FindBy(xpath="//a[text()='Bookings']")
	
	//@FindBy(xpath="//a[text()='Bookings']//parent::li")
	private WebElement bookings;
	
	@FindBy(xpath="//div[text()='Paid Bookings']")
	private WebElement paidbookingbutton;
	
	@FindBy(xpath="//th[text()='Payment Status']")
	private WebElement paymentstatus;
	
	@FindBy(xpath="//i[@class='fa fa-file']")
	private WebElement invoice;
	
	@FindBy(xpath="//div[text()='Cancelled Bookings']")
	private WebElement cancelledbooking;
	
	
	@FindBy(xpath="//i[@class='fa fa-times']")
	private WebElement delete;
	
	//@FindBy(xpath="//div[text()='Pending Bookings']")
	//private WebElement pendingbookings;
	
	@FindBy(xpath="//select[@class='form-select status pending']")
	private WebElement bookingstatus;
	
	
	
	public AdminDashboard(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		}
	
	public void ClickBookings() throws InterruptedException
	{
		
		bookings.click();
		Thread.sleep(4000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		 Thread.sleep(4000);
		 js.executeScript("window.scrollBy(0,-450)", "");
		 Thread.sleep(4000);
	}
	
	
	public void ClickPaidBookings() throws InterruptedException
	{
		
		paidbookingbutton.click();
		Thread.sleep(4000);
		}
	public void HighlightPaymentStatus() throws InterruptedException
	{
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
		jsExecutor.executeScript("arguments[0].style.border='2px solid red'", paymentstatus); 
		Thread.sleep(4000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,350)", "");
		
		}
	public void ViewInvoice() throws InterruptedException
	{
		
		invoice.click();
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
}
	
	public void ClickCancelledBookings() throws InterruptedException
	{
		
		cancelledbooking.click();
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		 Thread.sleep(4000);
}
	public void DeleteRecord() throws InterruptedException
	{
		
		delete.click();
		Thread.sleep(6000);
		
}
/*	public void ClickPendingBookings() throws InterruptedException
	{
		
		pendingbookings.click();
		Thread.sleep(4000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		 Thread.sleep(2000);
		
		}*/
	public void ChangeBookingStatus() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		 Thread.sleep(2000);
		Select select=new Select(bookingstatus);
		select.selectByVisibleText("Confirmed");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,-450)", "");
		Thread.sleep(2000);
			}
	
	
	
}









