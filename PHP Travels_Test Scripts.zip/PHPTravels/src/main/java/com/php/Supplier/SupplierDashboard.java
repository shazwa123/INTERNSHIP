package com.php.Supplier;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassSupplier;
public class SupplierDashboard extends BaseClassSupplier{
	WebDriver driver;
	@FindBy(xpath="//div[@class='text-muted']")
	private WebElement textchecking;

	@FindBy(xpath="//h2[@class='card-title mb-0']")
	private WebElement revenuedispaly;
	
	@FindBy(xpath="//a[text()='Bookings']")
	private WebElement bookings;
	
	@FindBy(xpath="//div[@id='container']")
	private WebElement error;
	
	
	@FindBy(xpath="//a[@data-bs-target='#toursmodule']")
	private WebElement tours;
	
	@FindBy(xpath="//a[@data-bs-target='#Tours']")
	private WebElement toursmodule;
	
	
	@FindBy(xpath="//a[text()='Manage Tours']")
	private WebElement managetours;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/api/supplier/tours/extras']")
	private WebElement extras;
	
	@FindBy(xpath="//i[@class='material-icons' and text()='person']")
	private WebElement icon;
	
	@FindBy(xpath="//i[@class='material-icons leading-icon' and text()='logout']")
	private WebElement logout;
	
	
	 public SupplierDashboard(WebDriver driver) {
			// TODO Auto-generated constructor stub
		
			this.driver=driver;
			PageFactory.initElements(driver,this);
			}
	 public String CheckTextIsPresentOrNot() throws InterruptedException
	 {
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
			jsExecutor.executeScript("arguments[0].style.border='2px solid red'",textchecking);
			Thread.sleep(3000);
		 String text= textchecking.getText();
			System.out.println("THE TEXT PRESENT IS:" +text);
			return text;
		
	 }
	 
	 public String CheckRevenueBreakdownIsPresentOrNot() throws InterruptedException
	 {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,450)", "");
			 Thread.sleep(2000);
			 js.executeScript("arguments[0].style.border='2px solid red'",revenuedispaly);
			Thread.sleep(3000);
		 String text1= revenuedispaly.getText();
			System.out.println("THE TEXT PRESENT IS:" +text1);
			return text1;
			
	 }
	 public void ClickBookings() throws InterruptedException
	 {
		 bookings.click();


			String title = driver.getTitle();
			System.out.println("PAGE HEADING IS:" +title);
			Thread.sleep(3000);
			String mssg = error.getText();			
			System.out.println("MESSAGE  IS:" +mssg);
			
	 }
	 public void clickToursModule() throws InterruptedException
	 {
tours.click();


toursmodule.click();
managetours.click();
Thread.sleep(2000);
driver.navigate().back();
Thread.sleep(6000);
tours.click();
Thread.sleep(2000);
toursmodule.click();
extras.click();
Thread.sleep(2000);
}
	 public void clickLogout() throws InterruptedException
	 {
		 icon.click();
		 Thread.sleep(2000);
		 logout.click();
	 }
	 
}