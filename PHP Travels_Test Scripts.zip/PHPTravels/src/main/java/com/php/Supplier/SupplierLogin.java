package com.php.Supplier;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassSupplier;

public class SupplierLogin extends BaseClassSupplier {
	WebDriver driver;

	@FindBy(xpath="//input[@name='email']")
	private WebElement Email;

	@FindBy(xpath="//input[@name='password']")
	private WebElement Password;

	@FindBy(xpath="//button[@type='submit']")
	private WebElement LoginButton;


		 public SupplierLogin(WebDriver driver) {
			// TODO Auto-generated constructor stub
		
			this.driver=driver;
			PageFactory.initElements(driver,this);
			}
		 
		public void EnterEmail(Object SupplierEmail) throws InterruptedException
		{
			Email.sendKeys(SupplierEmail.toString() );
			
		}
		
		public void EnterPassword(Object SupplierPassword) throws InterruptedException
		{
			Password.sendKeys(SupplierPassword.toString() );
			
		}
		public void ClearInvalidEmail(Object AdminEmail) throws InterruptedException
		{
			Email.clear();
			Thread.sleep(2000);
			Password.clear();
			Thread.sleep(2000);
			
		}
		public void ClickLogin() throws InterruptedException
		{
			
			LoginButton.click();
			Thread.sleep(4000);
		}

}


