package com.php.Agent;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassCustomer;

public class AgentDashboard extends BaseClassCustomer{
WebDriver driver;
	
	@FindBy(xpath="//a[text()=' My Bookings' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement mybookings; 
	
	
	
	
	@FindBy(xpath="//a[text()=' Add Funds' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement addfunds; 
	
	
	
	@FindBy(xpath="//a[text()=' My Profile' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement myprofile; 
	

	
	
	
	@FindBy(xpath="//a[text()=' Logout' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement logout;
	
	
	 public AgentDashboard(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
			}
	 
	 public void clickMyBookings() throws InterruptedException
	 {
		
		 mybookings.click();
		 Thread.sleep(2000);
		
	 }
	 
	
	 public void clickAddFunds() throws InterruptedException
	 {
		
		 addfunds.click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,450)", "");
		
	 }
	 
	 
	 
	 public void clickMyProfile() throws InterruptedException
	 {
		
		myprofile.click();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,750)", "");
		 Thread.sleep(2000);
		 
		
		  }
	 
	
	 public void Logout()
	 {
		 logout.click();
	 }
	 
}


