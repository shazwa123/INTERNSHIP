package com.test.Agent;

import java.io.IOException;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.php.Agent.AgentDashboard;
import com.php.Agent.AgentLinks;
import com.php.Agent.AgentLogin;
import com.php.Agent.AgentUpdate;
import com.php.Base.BaseClassCustomer;
import com.php.utilities.ExcelUtility;

public class TestClassAgent extends BaseClassCustomer
{
 AgentLogin agentobj;
 AgentDashboard agdobj;
 AgentLinks linkobj;
 AgentUpdate updateobj;
 
 @Test(priority = 1,description="Login to the Agent Dashboard page with invalid email and valid password")
	
	public void LogininToDashboardwithInvalidEmail() throws IOException, InterruptedException {
		
		agentobj=new AgentLogin(driver);
		
Object agentEmail=ExcelUtility.GetCellData(1, 3,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
		Object agentPassword=ExcelUtility.GetCellData(1,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
		agentobj.EnterEmail(agentEmail);
		Thread.sleep(2000);
		agentobj.EnterPassword(agentPassword);
		agentobj.ClickLogin();
		Thread.sleep(3000);
		agentobj.ClearInvalidEmail(agentEmail);
		agentobj.ClearInvalidEmail(agentPassword);
		Thread.sleep(2000);
		
		
}
@Test(priority = 2,description="Login to the Agent Dashboard page with valid email and password")
	
	public void LogininToDashboard() throws IOException, InterruptedException {
	agentobj=new AgentLogin(driver);
	
	Object agentEmail=ExcelUtility.GetCellData(3, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
			
			Object agentPassword=ExcelUtility.GetCellData(3,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
			agentobj.EnterEmail(agentEmail);
			Thread.sleep(2000);
			agentobj.EnterPassword(agentPassword);
			agentobj.ClickLogin();
			Thread.sleep(3000);
		
}

@Test(priority = 3 ,description="VERIFYING THE LINK MYBOOKINGS ")
public void VerifyingLinkMyBookings() throws InterruptedException
{
	agdobj=new AgentDashboard(driver);
	agdobj.clickMyBookings();
	Thread.sleep(4000);
	
}

@Test(priority = 4,description="VERIFYING THE LINK ADD FUNDS ")
public void VerifyingAddFunds() throws InterruptedException
{

	agdobj=new AgentDashboard(driver);
	agdobj.clickAddFunds();
	Thread.sleep(3000);
	
	
	
	}

@Test(priority = 5 ,description="VERIFYING THE LINK MY PROFILE ")
public void verifyingMyProfile() throws InterruptedException, IOException
{
agdobj.clickMyProfile();	
Thread.sleep(3000);


	}

@Test(priority = 6 ,description="VERIFYING THE LINK HOTELS ")
public void verifyingLinkHotels() throws InterruptedException, IOException
{
	linkobj=new AgentLinks(driver);
	linkobj.clickHotel();
Thread.sleep(3000);
Object cityname=ExcelUtility.GetCellData(3, 3,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
linkobj.Entercity(cityname);
Thread.sleep(3000);
linkobj.selectOptions();
Thread.sleep(3000);
linkobj.clickSearchButton();
Thread.sleep(6000);
driver.navigate().back();
Thread.sleep(3000);


	}

@Test(priority = 7 ,description="VERIFYING THE LINK FLIGHTS ")
public void verifyingLinkFlights() throws InterruptedException, IOException
{
	linkobj=new AgentLinks(driver);
	linkobj.clickFlights();
Thread.sleep(3000);
driver.navigate().back();
Thread.sleep(3000);
}

@Test(priority = 8 ,description="VERIFYING THE LINK Tours ")
public void verifyingLinkTours() throws InterruptedException, IOException
{
	linkobj=new AgentLinks(driver);
	linkobj.clickTours();
Thread.sleep(3000);
driver.navigate().back();
Thread.sleep(3000);
}

@Test(priority = 9 ,description="VERIFYING THE LINK VISA ")
public void verifyingLinkVisa() throws InterruptedException, IOException
{
	linkobj=new AgentLinks(driver);
	linkobj.clickVisa();
Thread.sleep(3000);
driver.navigate().back();
Thread.sleep(3000);
}

@Test(priority = 10 ,description="VERIFYING THE LINK BLOG ")
public void verifyingLinkBlog() throws InterruptedException, IOException
{
	linkobj=new AgentLinks(driver);
	linkobj.clickBlog();
Thread.sleep(3000);
driver.navigate().back();
Thread.sleep(3000);
}

@Test(priority = 11 ,description="VERIFYING THE LINK OFFERS")
public void verifyingLinkOffers() throws InterruptedException, IOException
{
	linkobj=new AgentLinks(driver);
	linkobj.clickOffers();
Thread.sleep(3000);
driver.navigate().back();
Thread.sleep(3000);
}

@Test(priority = 12 ,description="UPDATE USD to INR")
public void updateUsdToINR() throws InterruptedException, IOException
{
	updateobj=new AgentUpdate(driver);
	updateobj.selectUsd();
Thread.sleep(3000);
driver.navigate().back();
Thread.sleep(3000);

}
@Test(priority = 13 ,description="VERIFYING LOGOUT FUNCTIONALITY")
public void verifyingLogout() throws InterruptedException, IOException
{
	driver.navigate().back();
	Thread.sleep(3000);
	updateobj=new AgentUpdate(driver);
	updateobj.Logout();
Thread.sleep(3000);

}
}
