package com.test.Admin;

import java.io.IOException;

import java.util.Iterator;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.php.Admin.AdminDashboard;
import com.php.Admin.AdminLogin;
import com.php.Admin.Website;
import com.php.Base.BaseClassAdmin;
import com.php.utilities.ExcelUtility;


public class TestClassAdmin extends BaseClassAdmin {
	
	AdminLogin loginobj;
	AdminDashboard bookobj;
	Website wbobj;
@Test(priority = 1,description="Login to the Admin Dashboard page with invalid email and valid password")
	
	public void LogininToDashboardwithInvalidEmail() throws IOException, InterruptedException {
		
		loginobj=new AdminLogin(driver);
		
Object AdminEmail=ExcelUtility.GetCellData(1, 3,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
		Object AdminPassword=ExcelUtility.GetCellData(1,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
		loginobj.EnterEmail(AdminEmail);
		Thread.sleep(2000);
		loginobj.EnterPassword(AdminPassword);
		loginobj.ClickLogin();
		Thread.sleep(3000);
		boolean expected=true;
		boolean actual=loginobj.Errormessage();
		Assert.assertEquals(actual, expected);
		Thread.sleep(3000);
		// deleting the invalid email and re entering the valid email to enter in to the dashboard.
		
		loginobj.ClearInvalidEmail(AdminEmail);
		loginobj.ClearInvalidEmail(AdminPassword);
		Thread.sleep(2000);
		
}

@Test(priority = 2,description="Login to the Admin Dashboard page with invalid email and invalid password")

public void LogininToDashboardwithInvalidEmailInvalidPassword() throws IOException, InterruptedException {
	
	loginobj=new AdminLogin(driver);
	
Object AdminEmail=ExcelUtility.GetCellData(1, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
	Object AdminPassword=ExcelUtility.GetCellData(3,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);

	Thread.sleep(2000);
	loginobj.EnterEmail(AdminEmail);
	Thread.sleep(2000);
	loginobj.EnterPassword(AdminPassword);
	loginobj.ClickLogin();
	Thread.sleep(3000);
	
	loginobj.ClearInvalidEmail(AdminEmail);
	loginobj.ClearInvalidEmail(AdminPassword);
	Thread.sleep(2000);
	
}
	@Test(priority = 3 ,description="Login to the Admin Dashboard page with valid email and password")
	
	public void LogininToDashboard() throws IOException, InterruptedException {
		
		loginobj=new AdminLogin(driver);
		;
Object AdminEmail=ExcelUtility.GetCellData(1, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
		Object AdminPassword=ExcelUtility.GetCellData(1,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
		loginobj.EnterEmail(AdminEmail);
		loginobj.EnterPassword(AdminPassword);
		loginobj.ClickLogin();
		Thread.sleep(7000);
}
	

@Test(priority = 4 ,description="Verifying the link bookings and displaying the invoice where payment is succesful")
public void VerifyingBookingLinks() throws InterruptedException
{
	bookobj=new AdminDashboard(driver);
	bookobj.ClickBookings();
	Thread.sleep(3000);
	bookobj.ClickPaidBookings();
	Thread.sleep(3000);
	bookobj.HighlightPaymentStatus();
	Thread.sleep(3000);
	bookobj.ViewInvoice();
	Thread.sleep(7000);
	//close the invoice window
	Set<String> wnd1 = driver.getWindowHandles();
	
	//window handles iteration
	Iterator<String> i1 = wnd1.iterator();
	String prntw1 = i1.next();
	String popwnd1 = i1.next();
	//switching pop up window handle id
	driver.switchTo().window(popwnd1);
	driver.close();
	driver.switchTo().window(prntw1);
	Thread.sleep(2000);
	driver.navigate().back();
	
	Thread.sleep(5000);
	}

@Test(priority =5,description="Deleting a record where booking status is cancelled")
public void DeleteRecordCancelled() throws InterruptedException
{
	bookobj.ClickCancelledBookings();
	Thread.sleep(4000);
	bookobj.DeleteRecord();
	driver.switchTo().alert().accept();
	Thread.sleep(6000);
	driver.navigate().back();
	
}
@Test(priority =6,description="Updating the status of booking status from pending to confirmed")
public void UpdateBookingStatus() throws InterruptedException 
{
	//bookobj.ClickPendingBookings();
	Thread.sleep(4000);
	bookobj.ChangeBookingStatus();
	Thread.sleep(4000);
	 
	
}
@Test(priority =7,description="Verifying the link website")
public void VerifyingWorkingOfLinkWebsite() throws InterruptedException {
	Thread.sleep(4000);
	wbobj=new Website(driver);
	wbobj.ClickWebsite();
	Thread.sleep(6000);
}
}






